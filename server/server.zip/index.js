import express from 'express';
import mongoose from  'mongoose';
import router from './routes/user-routes.js';
import route from './routes/blog-routes.js';

const app =express();

app.use(express.json())
app.use("/api/user",router)
app.use("/api/blog",route)

mongoose.connect('mongodb+srv://yashu:yashu@cluster0.fofk29t.mongodb.net/?retryWrites=true&w=majority')
    .then(()=>
    app.listen(6000))
    .then(()=>
    console.log("listening to the port 6000 and connected to the mongoDB successfully"))
    .catch((err)=>console.log(err));

// const PORT = 5000;

// app.listen(PORT,()=>{
//     console.log(`listening to the port ${PORT}`)
// })